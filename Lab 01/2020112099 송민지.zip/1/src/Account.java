
public class Account {
	private String name;
	
	public Account(string name) {
		this.name = name;
	}
	
	public void setName(string name) {
		this.name name = name;
	}
	public String getName() {
		return name;
	}
}
